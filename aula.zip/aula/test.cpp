#include <bits/stdc++.h>
using namespace std;

int main(){

    bitset<1> bits;
    bits[0] = true;

    cout << true << endl;

}
