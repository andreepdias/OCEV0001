#include <bits/stdc++.h>
using namespace std;

#define BINARIO 0
#define INTEIRO 1
#define INTEIRO_PERMUTADO 2
#define REAL 3

class NQueens{

};

class Dominio_Inteiro{
public:
    Dominio_Inteiro(){}
    int locus_aleatorio(){
        return rand();
    }
};
class Dominio_Inteiro_Permutados{
public:
    Dominio_Inteiro(){}
    int locus_aleatorio(){
        return rand();
    }
};
class Dominio_Binario{
public:
    bool locus_aleatorio(){
        return rand() % 2 == 0 ? true : false;
    }
};
class Dominio_Real{
public:
    double locus_aleatorio(){
        return rand();
    }
};


// dominio
// limites upperbound, lowerbound (reais, inteiros)
// integridade (intervalo)
template <class T, class P>
class Populacao{
private:
    int tamanho_pop;
    int tamanho_cromossomo; //dimensionalidade
    vector<vector<T> > individuos;
    P op;

public:
    Populacao(int tp, int tc){
        tamanho_pop = tp;
        tamanho_cromossomo = tc;
        individuos.resize(tamanho_pop, vector<T>(tamanho_cromossomo));
    }

    void gerar_populacao_inicial(){
        for(int i = 0; i < tamanho_pop; i++){
            for(int j = 0; j < tamanho_cromossomo; j++){
                individuos[i][j] = op.locus_aleatorio();
            }
        }
    }
    void print_individuos(){
        for(int i = 0; i < tamanho_pop; i++){
            for(int j = 0; j < tamanho_cromossomo; j++){
                cout << individuos[i][j] << "\t";
            }
            cout << endl;
        }
    }
};


void ga_binario(){

}


int main(){
    srand(time(NULL));

    int tipo_variavel, tamanho_populacao, tamanho_cromossomo, tipo;

    ifstream arquivo_parametros;
    arquivo_parametros.open("parametros.txt");

    arquivo_parametros >> tipo_variavel;
    arquivo_parametros >> tamanho_populacao;
    arquivo_parametros >> tamanho_cromossomo;

    switch(tipo_variavel){
        case BINARIO:{
            Populacao <bool, Dominio_Binario> individuos_bin(tamanho_populacao, tamanho_cromossomo);
            break;
        }
        case INTEIRO:{
            Populacao <int, Dominio_Inteiro> individuos_int(tamanho_populacao, tamanho_cromossomo);
            break;
        }

        case INTEIRO_PERMUTADO:{
            Populacao <int, Dominio_Inteiro> individuos_intp(tamanho_populacao, tamanho_cromossomo);
            break;
        }

        case REAL:{
            Populacao <double, Dominio_Real> individuos_real(tamanho_populacao, tamanho_cromossomo);
            break;
        }

    }

}
